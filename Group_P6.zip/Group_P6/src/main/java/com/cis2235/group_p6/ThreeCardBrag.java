//Kaylee Nicasio
//knicasio1@cnm.edu
//Program 6 three card brag - Card Class
//ThreeCardBrag.java
package com.cis2235.group_p6;

import java.util.Arrays;
import java.util.Comparator;

public class ThreeCardBrag
{
    //Constants:
    public static final int NO_WINNER = 0;
    public static final int PLAYER1_WINS = 1;
    public static final int PLAYER2_WINS = 2;
    public static final int TIE = 3;

    private Card[] player1Hand;
    private Card[] player2Hand;
    //Variable to store the result(s):
    public int winningHand;


    //Sets hands & determines who won
    public void setPlayerHands(Card[] hand1, Card[] hand2)
    {
        this.player1Hand = hand1;
        this.player2Hand = hand2;
        whoWon();
    }

    //Returns results of last game:
    //Checks for no winner or if cards have not been dealt:
    public int getWinningHand()
    {
        if (player1Hand == null || player2Hand == null)
        {
            return NO_WINNER;
        }
        return winningHand;
    }

    //Checks who won:
    private void whoWon()
    {
        //Declare variables:
        int p1Points = calcHandPoints(player1Hand);
        int p2Points = calcHandPoints(player2Hand);

        //Compares hands:
        if (p1Points > p2Points)
        {
            winningHand = PLAYER1_WINS;
        } else if (p2Points > p1Points)
        {
            winningHand = PLAYER2_WINS;
        } else {
            winningHand = TIE;
        }
    }

    //Calc points based on game rules:
    private int calcHandPoints(Card[] hand)
    {
        //Sorts hand by value:
        Arrays.sort(hand, Comparator.comparingInt(Card::getRank));

        boolean isFlush = hand[0].getSuit() == hand[1].getSuit() && hand[1].getSuit() == hand[2].getSuit();
        //Ace can be high or low in a run:
        boolean isRun = (hand[2].getRank() == hand[1].getRank() + 1 && hand[1].getRank() == hand[0].getRank() + 1)
                // Ace low run (A,2,3)
                || (hand[2].getRank() == 14 && hand[1].getRank() == 3 && hand[0].getRank() == 2);

        boolean isThreeOfAKind = hand[0].getRank() == hand[1].getRank() && hand[1].getRank() == hand[2].getRank();
        boolean isRunningFlush = isFlush && isRun;
        boolean isPair = (hand[0].getRank() == hand[1].getRank()) || (hand[1].getRank() == hand[2].getRank()) || (hand[0].getRank() == hand[2].getRank());


        //Assign points:
        if (isThreeOfAKind) return 600 + hand[0].getRank();
        if(isRunningFlush) return 500 + hand[2].getRank();
        if(isRun) return 400 + hand[2].getRank();
        if(isFlush) return 300 + hand[2].getRank();
        if(isPair)
        {
            int pairValue = (hand[0].getRank() == hand[1].getRank())?hand[0].getRank() : hand[1].getRank();
            return 200 + pairValue;
        }
        return hand[2].getRank();

    }
}
