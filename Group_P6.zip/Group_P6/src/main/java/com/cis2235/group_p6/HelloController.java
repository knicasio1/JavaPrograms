package com.cis2235.group_p6;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class HelloController {

// fxml parts
    @FXML private TextArea rules_text;

    @FXML private TextField p1_name;
    @FXML private TextField p2_name;

    @FXML private ImageView img_p1_card1;
    @FXML private ImageView img_p1_card2;
    @FXML private ImageView img_p1_card3;

    @FXML private ImageView img_p2_card1;
    @FXML private ImageView img_p2_card2;
    @FXML private ImageView img_p2_card3;

    @FXML private TextArea winner_message;
    @FXML private TextArea scores_text;

    @FXML private Button deal_bttn;
    @FXML private Button show_winner_bttn;
    @FXML private Button playAgainBttn;

//game objects
    private CardDeck deck;
    private ThreeCardBrag brag;

    private Card[] player1Hand;
    private Card[] player2Hand;

    private String player1Name;
    private String player2Name;

    private int player1Score = 0;
    private int player2Score = 0;

    private int dealCount = 0;
    private final int MAX_DEALS = 8;

//initialize the game and fxml parts
    @FXML
    public void initialize() {

        deck = new CardDeck();
        brag = new ThreeCardBrag();

        player1Hand = new Card[3];
        player2Hand = new Card[3];

        rules_text.setText("Each player gets 3 cards. The player that holds the following cards wins: > Three 3's or an Ace > 2 or 3 of the same card (or suit)> King, Queen, or Jack. If both players have winning hands: Three 3's or an Ace beat a pair, which beats a face card. Good luck!" );

        showBackOfCards();

        winner_message.setText("Welcome to Three Card Brag!");
        scores_text.setText("Scores - P1: 0 | P2: 0");

        p1_name.setPromptText("Player 1 Name");
        p2_name.setPromptText("Player 2 Name");
    }

//the deal button
    @FXML
    private void handleDealButtonAction() {

        // keep names after first deal
        if (dealCount == 0) {
            player1Name = p1_name.getText().isEmpty() ? "Player 1" : p1_name.getText();
            player2Name = p2_name.getText().isEmpty() ? "Player 2" : p2_name.getText();
        }

        if (dealCount >= MAX_DEALS) {
            winner_message.setText("No more cards! Restart the game.");
            deal_bttn.setDisable(true);
            return;
        }

        dealCards();
        dealCount++;

        if (dealCount == MAX_DEALS) {
            deal_bttn.setDisable(true);
        }
    }

//determine winner button
    @FXML
    private void handleWinnerButtonAction() {
        determineWinner();
    }

//play again button handler
    @FXML
    private void handlePlayAgainButtonAction() {

        deck = new CardDeck();
        dealCount = 0;

        player1Score = 0;
        player2Score = 0;

        showBackOfCards();

        winner_message.setText("Game restarted — press Deal!");
        scores_text.setText("Scores - P1: 0 | P2: 0");

        deal_bttn.setDisable(false);
    }

//dealing logic
    private void dealCards() {

        for (int i = 0; i < 3; i++) {
            player1Hand[i] = deck.getNextCard();
            player2Hand[i] = deck.getNextCard();
        }

        //Card Images
        // player 1 card images
        img_p1_card1.setImage(loadCard(player1Hand[0]));
        img_p1_card2.setImage(loadCard(player1Hand[1]));
        img_p1_card3.setImage(loadCard(player1Hand[2]));

        //player 2 card images
        img_p2_card1.setImage(loadCard(player2Hand[0]));
        img_p2_card2.setImage(loadCard(player2Hand[1]));
        img_p2_card3.setImage(loadCard(player2Hand[2]));

        winner_message.setText("Cards dealt — press Show Winner!");
    }
//flip card
    private Image loadCard(Card c) {
        return new Image(getClass().getResourceAsStream("/com/cis2235/group_p6/" + c.getImageName()));
    }

//determine winner messages
    private void determineWinner() {

        brag.setPlayerHands(player1Hand, player2Hand);

        int winner = brag.getWinningHand();

        switch (winner) {

            case 1:
                winner_message.setText(player1Name + " wins this round!");
                player1Score++;
                break;

            case 2:
                winner_message.setText(player2Name + " wins this round!");
                player2Score++;
                break;

            case 3:
                winner_message.setText("It's a tie!");
                break;

            default:
                winner_message.setText("No winning hand!");
        }

        scores_text.setText(
                "Scores - " + player1Name + ": " + player1Score +
                        " | " + player2Name + ": " + player2Score
        );
    }

    //card backs
    private void showBackOfCards() {
        Image back = new Image(getClass().getResourceAsStream("/com/cis2235/group_p6/24065e38b5d25070e6080184bf1bdeb1.jpg"));

        img_p1_card1.setImage(back);
        img_p1_card2.setImage(back);
        img_p1_card3.setImage(back);

        img_p2_card1.setImage(back);
        img_p2_card2.setImage(back);
        img_p2_card3.setImage(back);
    }
}