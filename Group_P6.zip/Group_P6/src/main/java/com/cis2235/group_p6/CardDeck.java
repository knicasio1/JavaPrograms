//Stewart Martin
//smartin91@cnm.edu scmartinstewart@gmail.com
//Program 6 three card brag - Card Class
//CardDeck.Java
package com.cis2235.group_p6;

import java.util.Random;

public class CardDeck {
    private Card[] deck;
    private boolean[] cardDealt;
    private int cardDealtCount;
    private Card lastCardReturned;


    private Random rand;


    //constructor
    public CardDeck() {
        deck = new Card[52];
        cardDealt = new boolean[52];
        cardDealtCount = 0;
        lastCardReturned = null;
        rand = new Random();

        int index = 0;



        // spades
        deck[index++] = createCard(14, "spade", "Ace of Spades", "1.png");
        deck[index++] = createCard(13, "spade", "King of Spades", "2.png");
        deck[index++] = createCard(12, "spade", "Queen of Spades", "3.png");
        deck[index++] = createCard(11, "spade", "Jack of Spades", "4.png");
        deck[index++] = createCard(10, "spade", "10  of Spades", "5.png");
        deck[index++] = createCard(9, "spade", "9 of Spades", "6.png");
        deck[index++] = createCard(8, "spade", "8 of Spades", "7.png");
        deck[index++] = createCard(7, "spade", "7 of Spades", "8.png");
        deck[index++] = createCard(6, "spade", "6 of Spades", "9.png");
        deck[index++] = createCard(5, "spade", "5 of Spades", "10.png");
        deck[index++] = createCard(4, "spade", "4 of Spades", "11.png");
        deck[index++] = createCard(3, "spade", "3 of Spades", "12.png");
        deck[index++] = createCard(2, "spade", "2 of Spades", "13.png");

        //Hearts
        deck[index++] = createCard(14, "heart", "Ace of Hearts", "14.png");
        deck[index++] = createCard(13, "heart", "King of Hearts", "15.png");
        deck[index++] = createCard(12, "heart", "Queen of Hearts", "16.png");
        deck[index++] = createCard(11, "heart", "Jack of Hearts", "17.png");
        deck[index++] = createCard(10, "heart", "10 of Hearts", "18.png");
        deck[index++] = createCard(9, "heart", "9 of Hearts", "19.png");
        deck[index++] = createCard(8, "heart", "8 of Hearts", "20.png");
        deck[index++] = createCard(7, "heart", "7 of Hearts", "21.png");
        deck[index++] = createCard(6, "heart", "6 of Hearts", "22.png");
        deck[index++] = createCard(5, "heart", "5 of Hearts", "23.png");
        deck[index++] = createCard(4, "heart", "4 of Hearts", "24.png");
        deck[index++] = createCard(3, "heart", "3 of Hearts", "25.png");
        deck[index++] = createCard(2, "heart", "2 of Hearts", "26.png");


        //Diamonds
        deck[index++] = createCard(14, "diamonds", "Ace of Diamonds", "27.png");
        deck[index++] = createCard(13, "diamonds", "King of Diamonds", "28.png");
        deck[index++] = createCard(12, "diamonds", "Queen of Diamonds", "29.png");
        deck[index++] = createCard(11, "diamonds", "Jack of Diamonds", "30.png");
        deck[index++] = createCard(10, "diamonds", "10 of Diamonds", "31.png");
        deck[index++] = createCard(9, "diamonds", "9 of Diamonds", "32.png");
        deck[index++] = createCard(8, "diamonds", "8 of Diamonds", "33.png");
        deck[index++] = createCard(7, "diamonds", "7 of Diamonds", "34.png");
        deck[index++] = createCard(6, "diamonds", "6 of Diamonds", "35.png");
        deck[index++] = createCard(5, "diamonds", "5 of Diamonds", "36.png");
        deck[index++] = createCard(4, "diamonds", "4 of Diamonds", "37.png");
        deck[index++] = createCard(3, "diamonds", "3 of Diamonds", "38.png");
        deck[index++] = createCard(2, "diamonds", "2 of Diamonds", "39.png");

        //clubs
        deck[index++] = createCard(14, "clubs", "Ace of Clubs", "40.png");
        deck[index++] = createCard(13, "clubs", "King of Clubs", "41.png");
        deck[index++] = createCard(12, "clubs", "Queen of Clubs", "42.png");
        deck[index++] = createCard(11, "clubs", "Jack of Clubs", "43.png");
        deck[index++] = createCard(10, "clubs", "10 of Clubs", "44.png");
        deck[index++] = createCard(9, "clubs", "9 of Clubs", "45.png");
        deck[index++] = createCard(8, "clubs", "8 of Clubs", "46.png");
        deck[index++] = createCard(7, "clubs", "7 of Clubs", "47.png");
        deck[index++] = createCard(6, "clubs", "6 of Clubs", "48.png");
        deck[index++] = createCard(5, "clubs", "5 of Clubs", "49.png");
        deck[index++] = createCard(4, "clubs", "4 of Clubs", "50.png");
        deck[index++] = createCard(3, "clubs", "3 of Clubs", "51.png");
        deck[index++] = createCard(2, "clubs", "2 of Clubs", "52.png");

        // mark all cards as not dealt
        for (int i = 0; i < 52; i++) {
            cardDealt[i] = false;

        }
    }

    // creates cards helper
    private Card createCard(int rank, String suit, String fullName, String imageName) {
        Card c = new Card();
        c.setRank(rank);
        c.setSuit(suit);
        c.setImageName(imageName);
        c.setFullName(fullName);
        return c;
    }

    //get next card
    public Card getNextCard()
    {
        if (cardDealtCount >= 52)
        {
            return lastCardReturned;
        }

        int index;
        do
        {
            index = rand.nextInt(52);
        } while (cardDealt[index]);

        cardDealt[index] = true;
        cardDealtCount++;
        lastCardReturned = deck[index];

        return deck[index];

    }

    public int getCardDealtCount()
    {
        return cardDealtCount;
    }

    public void resetDeck() {
        for (int i = 0; i < 52; i++)
        {
            cardDealt[i] = false;
        }
        cardDealtCount = 0;
        lastCardReturned = null;
    }
}


