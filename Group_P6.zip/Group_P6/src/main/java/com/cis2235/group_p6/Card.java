//Stewart Martin
//smartin91@cnm.edu scmartinstewart@gmail.com
//Program 6 three card brag - Card Class
//Card.Java
package com.cis2235.group_p6;


public class Card
{
    private int rank;           // 2–14 (Ace = 14)
    private String suit;        // spade, heart, diamond, club
    private String imageName;   // "1.png"
    private String fullName;    // "Ace of Spades"

    // -----------------------------------------
    // Default constructor
    // -----------------------------------------
    public Card()
    {
        rank = 0;
        suit = "";
        imageName = "";
        fullName = "";
    }

    // -----------------------------------------
    // Setters
    // -----------------------------------------
    public void setRank(int rank)
    {
        this.rank = rank;
    }

    public void setSuit(String suit)
    {
        this.suit = suit;
    }

    public void setImageName(String imageName)
    {
        this.imageName = imageName;
    }

    public void setFullName(String fullName)
    {
        this.fullName = fullName;
    }

    // -----------------------------------------
    // Getters
    // -----------------------------------------
    public int getRank()
    {
        return rank;
    }

    public String getSuit()
    {
        return suit;
    }

    public String getImageName()
    {
        return imageName;
    }

    public String getFullName()
    {
        return fullName;
    }

    // -----------------------------------------
    // For debugging (shows card info as text)
    // -----------------------------------------
    @Override
    public String toString()
    {
        return fullName + " (" + suit + ", rank " + rank + ")";
    }
}