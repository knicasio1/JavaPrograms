module com.cis2235.group_p6 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.cis2235.group_p6 to javafx.fxml;
    exports com.cis2235.group_p6;
}